#include <stdio.h>


void fun(void);

int main(){

	int y;
	y = 0;
	fun();
	y++;
	if (y != 0){
		printf("You Lose\n");
	} else {
		printf("You Win!!\n");
	}
	return 0;
}

void fun(){
	char s[32];
	gets(s);
}

