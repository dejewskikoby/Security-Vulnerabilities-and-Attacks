#include <stdio.h>



int main(){

	char s[32];
	int x;
	x = 0;
	
	gets(s);

	if (x == 39457){
		printf("You Win!!\n");
	} else {
		printf("You lose. \n");
	}

	return 0;
}


