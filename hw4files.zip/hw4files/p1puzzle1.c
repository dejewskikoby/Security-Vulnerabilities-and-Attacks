#include <stdio.h>


int main(){

	char s[64];
	int x;
	x = 0;
	
	gets(s);

	if (x){
		printf("You Win!!\n");
	} else {
		printf("You lose. \n");
	}

	return 0;
}


