#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	char s[128];
	char t[16];
	int *x;
	
	/*
	assign to x the address of an 
	integer-sized chunk on the heap 
	*/
	x = malloc(1*sizeof(int));
	
	/*
	put the secret number in this chunk on the heap.
	it's your job to figure out what this value is
	*/
	*x = ???;
	
	printf("The hidden value is at address %p \n", x);
	printf("Enter your string: ");
	
	fgets(s, 128, stdin);
	printf("You typed ");
	printf(s);

	printf("Enter your number guess: ");

	fgets(t, 16, stdin);
	/* fgets also captures your newline, so 
	replace that with a null character
	*/
	t[strlen(t)-1]='\0';
	
	/* 
	if you correctly guess integer value x 
	points to, you win!
	*/
	if (atoi(t) == *x){
		printf("You Win!!\n");
	} else {
		printf("You Lose\n");
	}

	return 0;
}

