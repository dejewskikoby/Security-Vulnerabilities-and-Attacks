#include <stdio.h>

int main(){
	myfun(5);
	return 0;
}

int myfun(int n){
	char s[128];
	int x;
	
	x = 0;

	fgets(s,128,stdin);
	printf(s);


	printf("x is %d \n", x);
	printf("s starts at %p \n", s);

	if (x != 199){
		printf("\nYou Lose. \n",x);
	} else {
		printf("\nYou Win!!\n");
	}
	return 0;
}

