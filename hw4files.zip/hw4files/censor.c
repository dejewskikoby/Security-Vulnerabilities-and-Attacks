#include <stdio.h>
#include <string.h>

int replace_fourletter_word(char text[], char * word);

int main(int argc, char *argv[]){
	char filecontents[1000];
	char * filename = argv[1];
	char * word_to_replace = argv[2];
	FILE * fp;
       
	if ((fp = fopen(filename, "r"))==NULL){
		printf("Error reading file \n");
		return -1;
	}
	printf("File contents at %p \n", filecontents);	
	fread(filecontents, 1000,1, fp);

	replace_fourletter_word(filecontents, word_to_replace);

	printf("%s", filecontents);	
}


int replace_fourletter_word(char text[], char * word){
	char *spot;
	char target[8];
	strcpy(target, word);

	while ((spot = strstr(text, word)) != NULL){
		strncpy(spot, "****",4);
	}
	return 0;
}
