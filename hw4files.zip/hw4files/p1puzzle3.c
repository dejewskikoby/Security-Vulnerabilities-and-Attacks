#include <stdio.h>

void fun();
void lose();
void win();


int main(){

	fun();
	lose();
	return 0;
}

void fun(){
	char s[16];
	gets(s);
}

void lose(){
	printf("Sorry, you lose.\n");
}

void win(){
	printf("You Win!!\n");
}



